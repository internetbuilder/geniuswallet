<script>
window.Print.postMessage('{"status":true, "data": "Payment Completed Successfully", "error" : ""}');
</script>