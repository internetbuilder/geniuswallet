

<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('Cash Out'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php echo app('translator')->get('Cash Out'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-xl">
    <div class="row row-deck row-cards">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="" id="form" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <div class="form-label"><?php echo app('translator')->get('Agent Email'); ?> <span class="ms-2 check"></span></div>
                                <div class="input-group">
                                    <input type="text" name="receiver" id="receiver"
                                        class="form-control shadow-none receiver" required>
                                    <button type="button" data-bs-toggle="tooltip" data-bs-original-title="Scan QR code"
                                        class="input-group-text scan"><i class="fas fa-qrcode"></i></button>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="form-label"><?php echo app('translator')->get('Select Wallet'); ?></div>
                                <select class="form-select wallet shadow-none" name="wallet_id">
                                    <option value="" selected><?php echo app('translator')->get('Select'); ?></option>
                                    <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($wallet->id); ?>" data-rate="<?php echo e($wallet->currency->rate); ?>"
                                        data-code="<?php echo e($wallet->currency->code); ?>" data-type="<?php echo e($wallet->currency->type); ?>">
                                        <?php echo e($wallet->currency->code); ?> --
                                        (<?php echo e(amount($wallet->balance,$wallet->currency->type,3)); ?>)</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="form-label "><?php echo app('translator')->get('Amount : '); ?> <code
                                        class="limit"><?php echo app('translator')->get('min : '.$charge->minimum.' '.$gs->curr_code); ?> -- <?php echo app('translator')->get('max : '.$charge->maximum.' '.$gs->curr_code); ?></code>
                                </div>
                                <input type="number" step="any" name="amount" id="amount"
                                    class="form-control shadow-none mb-2" disabled required>
                                <small class="text-danger charge"></small>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="form-label">&nbsp;</div>
                                <a href="#" class="btn btn-primary w-100 transfer">
                                    <?php echo app('translator')->get('Cash Out'); ?>
                                </a>
                            </div>


                            <div class="modal modal-blur fade" id="modal-success" tabindex="-1" role="dialog"
                                aria-hidden="true">
                                <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                        <div class="modal-status bg-primary"></div>
                                        <div class="modal-body text-center py-4">
                                            <i class="fas fa-info-circle fa-3x text-primary mb-2"></i>
                                            <h3><?php echo app('translator')->get('Preview Cash Out'); ?></h3>
                                            <ul class="list-group mt-2">
                                                <li class="list-group-item d-flex justify-content-between">
                                                    <?php echo app('translator')->get('Request Amount'); ?><span class="amount"></span></li>
                                                <li class="list-group-item d-flex justify-content-between"><?php echo app('translator')->get('Total
                                                    Charge'); ?><span class="charge"></span></li>
                                                <li class="list-group-item d-flex justify-content-between"><?php echo app('translator')->get('Total
                                                    Amount'); ?><span class="total_amount"></span></li>
                                            </ul>
                                        </div>
                                        <div class="modal-footer">
                                            <div class="w-100">
                                                <div class="row">
                                                    <div class="col"><a href="#" class="btn w-100"
                                                            data-bs-dismiss="modal">
                                                            <?php echo app('translator')->get('Cancel'); ?>
                                                        </a></div>
                                                    <div class="col">
                                                        <button type="button" class="btn btn-primary w-100 confirm">
                                                            <?php echo app('translator')->get('Confirm'); ?>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    'use strict';
        $('.receiver').on('focusout',function () { 
            var url   = '<?php echo e(route('user.check.agent')); ?>';
            var value = $(this).val();
            var token = '<?php echo e(csrf_token()); ?>';
            var data  = {receiver:value,_token:token}
           
            $.post(url,data,function(res) {
                if(res.self){
                    if($('.check').hasClass('text-success')){
                        $('.check').removeClass('text-success');
                    }
                    $('.check').addClass('text-danger').text(res.self);
                    $('.transfer').attr('disabled',true)
                    return false
                }
                if(res['data'] != null){
                    if($('.check').hasClass('text-danger')){
                        $('.check').removeClass('text-danger');
                    }
                    $('.check').text(`<?php echo app('translator')->get('Valid agent found.'); ?>`).addClass('text-success');
                    $('.transfer').attr('disabled',false)
                } else {
                    if($('.check').hasClass('text-success')){
                        $('.check').removeClass('text-success');
                    }
                    $('.check').text('<?php echo app('translator')->get('Agent not found.'); ?>').addClass('text-danger');
                    
                }
            });
        })

        $('.transfer').on('click',function () { 

            var amount = parseFloat($('#amount').val());
            var selected = $('.wallet option:selected')

            if($('#receiver').val() == '' || amount == '' || selected.val() == ''){
                toast('error','<?php echo app('translator')->get('Please fill up the required fields'); ?>')
                return false;
            }
            if($('#amount').val() < limit().minLimit || $('#amount').val() > limit().maxLimit){
                toast('error','<?php echo app('translator')->get('Please follow the limit.'); ?>')
                return false;
            }
           
            $('#modal-success').find('.amount').text(amount +' '+selected.data('code'))
            $('#modal-success').find('.charge').text(charge().final +' '+ selected.data('code'))
            $('#modal-success').find('.total_amount').text((charge().final+amount).toFixed(3) +' '+selected.data('code'))
            $('#modal-success').modal('show')
        })

        $('.confirm').on('click',function () { 
            $('#form').submit()
            $(this).attr('disabled',true)
        })

        function limit() { 
            var selected = $('.wallet option:selected')
            var rate = selected.data('rate')

            var minimum = '<?php echo e($charge->minimum); ?>'
            var maximum = '<?php echo e($charge->maximum); ?>'

            var minLimit = minimum * rate;
            var maxLimit = maximum * rate;

            return {'minLimit': minLimit,'maxLimit': maxLimit};
        }

        function charge() { 
            var selected = $('.wallet option:selected')
            var rate = selected.data('rate')
            var amount = $('#amount').val()

            var fixedCharge   = '<?php echo e($charge->fixed_charge); ?>'
            var percentCharge = '<?php echo e($charge->percent_charge); ?>'
            var fixed = fixedCharge * rate

            var finalCharge =  fixed + (amount * (percentCharge/100))

            return {'final':finalCharge,'fixed':fixed,'percent':percentCharge};

        }

        $('.wallet').on('change',function () { 
            var selected = $('.wallet option:selected');
           if(selected.val() == ''){
            $('#amount').attr('disabled',true)
              return false
            } else{
              $('#amount').attr('disabled',false)
            }

            var type = selected.data('type')
            var code = $('.wallet option:selected').data('code')
            var minLimit = limit().minLimit;
            var maxLimit = limit().maxLimit;
            $('.limit').text("<?php echo app('translator')->get('min'); ?> : "+amount(minLimit,type)+' '+code+" -- <?php echo app('translator')->get('max'); ?> : "+amount(maxLimit,type)+' '+code)
            $('.charge').text("<?php echo app('translator')->get('Total Charge'); ?> : " +amount(charge().fixed,type) +' '+code+' + '+charge().percent + '%')
        })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cleantech/public_html/wallet-laravel-10/project/resources/views/user/withdraw/cashout.blade.php ENDPATH**/ ?>