

<?php $__env->startSection('title'); ?>
   <?php echo app('translator')->get('Transactions'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo app('translator')->get('Transactions'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('extra'); ?>
   <form action="" class="d-flex justify-content-end">
    <div class="form-group me-2">
      <select  class="form-control me-2 shadow-none" onChange="window.location.href=this.value">
        <option value="<?php echo e(filter('remark','')); ?>"><?php echo app('translator')->get('All Remark'); ?></option>
            <option value="<?php echo e(filter('remark','transfer_money')); ?>" <?php echo e(request('remark') == 'transfer_money' ? 'selected':''); ?>><?php echo app('translator')->get('Transfer Money'); ?></option>
          
            <option value="<?php echo e(filter('remark','request_money')); ?>" <?php echo e(request('remark') == 'request_money' ? 'selected':''); ?>><?php echo app('translator')->get('Request Money'); ?></option>
            
            <option value="<?php echo e(filter('remark','money_exchange')); ?>" <?php echo e(request('remark') == 'money_exchange' ? 'selected':''); ?>><?php echo app('translator')->get('Money Exchange'); ?></option>
            
            <option value="<?php echo e(filter('remark','invoice_payment')); ?>" <?php echo e(request('remark') == 'invoice_payment' ? 'selected':''); ?>><?php echo app('translator')->get('Invoice Payment'); ?></option>
          
            <option value="<?php echo e(filter('remark','merchant_payment')); ?>" <?php echo e(request('remark') == 'merchant_payment' ? 'selected':''); ?>><?php echo app('translator')->get('Merchant Payment'); ?></option>
          
            <option value="<?php echo e(filter('remark','merchant_api_payment')); ?>" <?php echo e(request('remark') ==  'merchant_api_payment' ? 'selected':''); ?>><?php echo app('translator')->get('Merchant API Payment'); ?></option>
          
            <option value="<?php echo e(filter('remark','escrow_return')); ?>" <?php echo e(request('remark') == 'escrow_return' ? 'selected':''); ?>><?php echo app('translator')->get('Escrow Return'); ?></option>
          
            <option value="<?php echo e(filter('remark','make_escrow')); ?>" <?php echo e(request('remark') == 'make_escrow' ? 'selected':''); ?>><?php echo app('translator')->get('Make Escrow'); ?></option>
  
            <option value="<?php echo e(filter('remark','withdraw_money')); ?>" <?php echo e(request('remark') == 'withdraw_money' ? 'selected':''); ?>><?php echo app('translator')->get('Withdraw Money'); ?></option>

            <option value="<?php echo e(filter('remark','withdraw_reject')); ?>" <?php echo e(request('remark') == 'withdraw_reject' ? 'selected':''); ?>><?php echo app('translator')->get('Withdraw Reject'); ?></option>
  
            <option value="<?php echo e(filter('remark','redeem_voucher')); ?>" <?php echo e(request('remark') == 'redeem_voucher' ? 'selected':''); ?>><?php echo app('translator')->get('Redeem Voucher'); ?></option>
  
            <option value="<?php echo e(filter('remark','create_voucher')); ?>" <?php echo e(request('remark') == 'create_voucher' ? 'selected':''); ?>><?php echo app('translator')->get('Create Voucher'); ?></option>

            <option value="<?php echo e(filter('remark','deposit')); ?>" <?php echo e(request('remark') == 'deposit' ? 'selected':''); ?>><?php echo app('translator')->get('Deposit'); ?></option>

            <option value="<?php echo e(filter('remark','cash_in')); ?>" <?php echo e(request('remark') == 'cash_in' ? 'selected':''); ?>><?php echo app('translator')->get('Cash In'); ?></option>

            <option value="<?php echo e(filter('remark','cash_out')); ?>" <?php echo e(request('remark') == 'cash_out' ? 'selected':''); ?>><?php echo app('translator')->get('Cash Out'); ?></option>
      </select>
    </div>
    <div class="form-group">
      <div class="input-group">
          <input type="text" class="form-control shadow-none" value="<?php echo e($search ?? ''); ?>" name="search" placeholder="<?php echo app('translator')->get('Transaction ID'); ?>">
              <button class="input-group-text btn btn-primary text-white" id="my-addon"><i class="fas fa-search"></i>
              </button>
      </div>
  </div>
   </form>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xl">
        <div class="row row-deck row-cards">
            <div class="col-md-12">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title"><?php echo app('translator')->get('Transactions'); ?></h3>
                  </div>
                 
                  <div class="table-responsive">
                    <table class="table card-table table-vcenter text-nowrap datatable">
                      <thead>
                        <tr>
                          <th><?php echo app('translator')->get('Date'); ?></th>
                          <th><?php echo app('translator')->get('Transaction ID'); ?></th>
                          <th><?php echo app('translator')->get('Remark'); ?></th>
                          <th><?php echo app('translator')->get('Amount'); ?></th>
                          <th><?php echo app('translator')->get('Details'); ?></th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <tr>
                            <td data-label="<?php echo app('translator')->get('Date'); ?>"><?php echo e(dateFormat($item->created_at,'d-M-Y')); ?></td>
                            <td data-label="<?php echo app('translator')->get('Transaction ID'); ?>">
                              <?php echo e(__($item->trnx)); ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Remark'); ?>">
                              <span class="badge badge-dark"><?php echo e(ucwords(str_replace('_',' ',$item->remark))); ?></span>
                            </td>
                            <td data-label="<?php echo app('translator')->get('Amount'); ?>">
                                <span class="<?php echo e($item->type == '+' ? 'text-success':'text-danger'); ?>"><?php echo e($item->type); ?> <?php echo e(amount($item->amount,$item->currency->type,2)); ?> <?php echo e($item->currency->code); ?></span> 
                            </td>
                            <td data-label="<?php echo app('translator')->get('Details'); ?>">
                                <button class="btn btn-primary btn-sm details" data-data="<?php echo e($item); ?>"><?php echo app('translator')->get('Details'); ?></button>
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td class="text-center" colspan="12"><?php echo app('translator')->get('No data found!'); ?></td></tr>
                        <?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                  <?php if($transactions->hasPages()): ?>
                      <div class="card-footer">
                          <?php echo e($transactions->links()); ?>

                      </div>
                  <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="modal modal-blur fade" id="modal-success" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            <div class="modal-status bg-primary"></div>
            <div class="modal-body text-center py-4">
            <i  class="fas fa-info-circle fa-3x text-primary mb-2"></i>
            <h3><?php echo app('translator')->get('Transaction Details'); ?></h3>
            <p class="trx_details"></p>
            <ul class="list-group mt-2">
               
            </ul>
            </div>
            <div class="modal-footer">
            <div class="w-100">
                <div class="row">
                <div class="col"><a href="#" class="btn w-100" data-bs-dismiss="modal">
                    <?php echo app('translator')->get('Close'); ?>
                    </a></div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
      'use strict';
   
      $('.details').on('click',function () { 
        var url = "<?php echo e(url('user/transaction/details/')); ?>"+'/'+$(this).data('data').id
        $('.trx_details').text($(this).data('data').details)
        $.get(url,function (res) { 
          if(res == 'empty'){
            $('.list-group').html('<p><?php echo app('translator')->get('No details found!'); ?></p>')
          }else{
            $('.list-group').html(res)
          }
          $('#modal-success').modal('show')
        })
      })
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cleantech/public_html/wallet-laravel-10/project/resources/views/user/transactions.blade.php ENDPATH**/ ?>