   <!-- Header -->
   <?php
       $socials = App\Models\SiteContent::where('slug','social')->first();
   ?>
   <div class="navbar-top bg--base">
    <div class="container">
        <div class="d-flex flex-wrap justify-content-evenly justify-content-md-between">
            <ul class="social-icons py-1 py-md-0">
                <?php $__currentLoopData = $socials->sub_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a target="_blank" href="<?php echo e(@$item->url); ?>"><i class="<?php echo e(@$item->icon); ?>"></i></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <ul class="contact-bar py-1 py-md-0">
                <li>
                    <a href="Tel:<?php echo e($contact->content->phone); ?>"><?php echo e($contact->content->phone); ?></a>
                </li>
                <li>
                    <a href="Mailto:<?php echo e($contact->content->email); ?>"><?php echo e($contact->content->email); ?></a>
                </li>
                <li>
                    <div class="change-language d-none d-sm-block">
                        <select class="language-bar" onChange="window.location.href=this.value">
                            <?php $__currentLoopData = DB::table('languages')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <option value="<?php echo e(route('lang.change',$item->code)); ?>" <?php echo e(session('lang') == $item->code ? 'selected':''); ?>><?php echo app('translator')->get($item->language); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="navbar-bottom">
    <div class="container">
        <div class="navbar-wrapper">
            <div class="logo">
                <a href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(getPhoto($gs->header_logo)); ?>" alt="logo" />
                </a>
            </div>
            <div class="change-language d-sm-none ms-auto me-3 text--title">
                <select class="language-bar" onChange="window.location.href=this.value">
                    <?php $__currentLoopData = DB::table('languages')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e(route('lang.change',$item->code)); ?>" <?php echo e(session('lang') == $item->code ? 'selected':''); ?>><?php echo app('translator')->get($item->language); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="nav-toggle d-lg-none">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="nav-menu-area">
                <div class="menu-close text--danger d-lg-none">
                    <i class="fas fa-times"></i>
                </div>
                <ul class="nav-menu">
                    <?php $__currentLoopData = json_decode($gs->menu); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                           <a target="<?php echo e($item->target == 'self' ? '':'_blank'); ?>" href="<?php echo e(url($item->href)); ?>"><?php echo e(__($item->title)); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                    <li>
                        <?php if(auth()->guard()->check()): ?>
                        <div class="btn__grp ms-lg-3">
                            <a href="<?php echo e(route('user.dashboard')); ?>" class="cmn--btn"><?php echo app('translator')->get('Dashboard'); ?></a>
                            <a href="<?php echo e(route('user.logout')); ?>" class="cmn--btn btn-outline"><?php echo app('translator')->get('Logout'); ?></a>
                        </div>
                        <?php else: ?>
                        <div class="btn__grp ms-lg-3">
                            <a href="<?php echo e(route('user.login')); ?>" class="cmn--btn"><?php echo app('translator')->get('Login'); ?></a>
                            <a href="<?php echo e(route('user.register')); ?>" class="cmn--btn btn-outline"><?php echo app('translator')->get('Register'); ?></a>
                        </div>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Header --><?php /**PATH C:\xampp\htdocs\wallet_update\wallet_with_addon\project\resources\views/frontend/partials/header.blade.php ENDPATH**/ ?>