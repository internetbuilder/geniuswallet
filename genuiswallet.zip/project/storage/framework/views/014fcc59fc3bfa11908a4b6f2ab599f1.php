

<?php $__env->startSection('title'); ?>
   <?php echo app('translator')->get('Profile Setting'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
 <section class="section">
    <div class="section-header">
        <h1><?php echo app('translator')->get('Profile Setting'); ?></h1>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label class="col-form-label"><?php echo app('translator')->get('Profile Picture'); ?></label>
                        <div id="image-preview" class="image-preview ml-auto mr-auto"
                            style="background-image:url(<?php echo e(getPhoto( @$user->photo)); ?>);">
                            <label for="image-upload" id="image-label"><?php echo app('translator')->get('Choose File'); ?></label>
                            <input type="file" name="photo" id="image-upload" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Business Name'); ?></label>
                             <input class="form-control" name="business_name" type="text" value="<?php echo e(@$user->business_name); ?>" required>
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Your Name'); ?></label>
                            <input class="form-control" name="name" type="text" value="<?php echo e(@$user->name); ?>" required>
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Email'); ?></label>
                            <input class="form-control"  type="email" value="<?php echo e(@$user->email); ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Phone'); ?></label>
                            <input class="form-control" disabled type="text" value="<?php echo e(@$user->phone); ?>" required>
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Country'); ?></label>
                            <input class="form-control" disabled type="text" value="<?php echo e(@$user->country); ?>" required>
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('City'); ?></label>
                            <input class="form-control" name="city" type="text" value="<?php echo e(@$user->city); ?>" required>
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Address'); ?></label>
                            <input class="form-control" name="address" type="text" value="<?php echo e(@$user->address); ?>" required>
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Zip'); ?></label>
                            <input class="form-control" name="zip" type="text" value="<?php echo e(@$user->zip); ?>" required>
                        </div>
                        <div class="form-group mt-3 text-right">
                            <button type="submit" class="btn btn-primary btn-lg"><?php echo app('translator')->get('Submit'); ?></button>
                        </div>
                    </div>
                </div>
            
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        $.uploadPreview({
                input_field: "#image-upload", // Default: .image-upload
                preview_box: "#image-preview", // Default: .image-preview
                label_field: "#image-label", // Default: .image-label
                label_default: "<?php echo e(__('Choose File')); ?>", // Default: Choose File
                label_selected: "<?php echo e(__('Update Image')); ?>", // Default: Change File
                no_label: false, // Default: false
                success_callback: null // Default: null
            });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.agent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demoroyal/public_html/wallet-laravel-10/project/resources/views/agent/profile_setting.blade.php ENDPATH**/ ?>